//EmbeddedCertManager
document.write('<OBJECT ID="EMX" CLASSID="CLSID:4725E26C-87F5-4D06-B743-A645DC6623D9" WIDTH = 285 HEIGHT = 145>'); 
document.write('<PARAM NAME="GNTYPE", VALUE=GNCertType>');
document.write('<PARAM NAME="WORKDIR", VALUE=WorkDir>');
document.write('<PARAM NAME="CERTTYPE", VALUE=ReadCertType>');
document.write('<PARAM NAME="GNVALIDCERTOIDINFOTYPE", VALUE=ValidCertInfo>');
document.write('</OBJECT>');
